# 16-bit-RISC-processor
Verilog code for ALU and Control unit of a 16-Bit RISC processor
